<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
    <p>Пользователь заказал песню.</p>
    <p>Имя: <?php echo $name; ?></p>
    <p>Для кого: <?php echo $for_name; ?></p>
    <p>Название песни: <?php echo $song; ?></p>
    <p>Город: <?php echo $city; ?></p>
    <p>Номер телефона: <?php echo $phone; ?></p>
    <p>Сообщение: <?php echo $message; ?></p>
</body>
</html>