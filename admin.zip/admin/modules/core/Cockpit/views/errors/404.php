<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page not found</title>
    @assets($app['app.assets.base'], 'app.base', 'cache:assets', 0)
</head>
<body>
    <div class="app-wrapper uk-text-center uk-animation-slide-bottom" style="margin-top:100px;">
        <h1><strong><i class="uk-icon-times"></i> 404</strong></h1>

        <p class="uk-text-large">Uuuups, Page not found.</p>
    </div>
</body>
</html>