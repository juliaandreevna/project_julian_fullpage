<?php
return [
    "mailer"            => [
        "from"      => "mailer@it-technologies.us",
        "fromName"	=> "Julian Radio",
        "reply_to"	=> "manager@it-technologies.us",
        "transport" => "smtp",
        "host"      => "smtp.yandex.ru",
        "user"      => "mailer@it-technologies.us",
        "password"  => "1q2w3e4z5x",
        "port"      => 465,
        "auth"      => true,
        "encryption"=> "ssl"
    ]
];
?>

